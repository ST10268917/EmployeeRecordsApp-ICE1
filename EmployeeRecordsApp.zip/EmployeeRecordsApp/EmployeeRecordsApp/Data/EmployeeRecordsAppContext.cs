﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using EmployeeRecordsApp.Models;

namespace EmployeeRecordsApp.Data
{
    public class EmployeeRecordsAppContext : DbContext
    {
        public EmployeeRecordsAppContext (DbContextOptions<EmployeeRecordsAppContext> options)
            : base(options)
        {
        }

        public DbSet<EmployeeRecordsApp.Models.Employee> Employee { get; set; } = default!;
    }
}
