﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using EmployeeRecordsApp.Data;
using System;
using System.Linq;

namespace EmployeeRecordsApp.Models
{
    public class SeedData
    {
        public static void Initialize(IServiceProvider serviceProvider)
        {
            using (var context = new EmployeeRecordsAppContext(
                serviceProvider.GetRequiredService<
                    DbContextOptions<EmployeeRecordsAppContext>>()))
            {
                // Look for any movies.
                if (context.Employee.Any())
                {
                    return;   // DB has been seeded
                }
                context.Employee.AddRange(
                    new Employee
                    {
                        Name = "Jack Bauer",
                        DateJoined = DateTime.Parse("1989-2-12"),
                        Role = "General Manager",
                        Salary = 60000
                    },
                    new Employee
                    {
                        Name = "Angela Yu",
                        DateJoined = DateTime.Parse("1984-7-12"),
                        Role = "CEO",
                        Salary = 90000
                    },
                    new Employee
                    {
                        Name = "Muhamamd Adam",
                        DateJoined = DateTime.Parse("1986-2-23"),
                        Role = "IT Specialist",
                        Salary = 75000
                    },
                    new Employee
                    {
                        Name = "Adam Shaikh",
                        DateJoined = DateTime.Parse("1959-4-15"),
                        Role = "COO",
                        Salary = 80000
                    }
                );
                context.SaveChanges();
            }
        }
    }
}
