﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System.Collections.Generic;

namespace EmployeeRecordsApp.Models
{
    public class EmployeeRoleViewModel
    {
        public List<Employee>? Employees { get; set; }
        public SelectList? Roles { get; set; }
        public string? EmployeeRole { get; set; }
        public string? SearchString { get; set; }
    }
}
